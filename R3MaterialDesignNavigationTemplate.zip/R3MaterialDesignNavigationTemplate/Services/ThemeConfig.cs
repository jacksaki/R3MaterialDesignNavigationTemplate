﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace R3MaterialDesignNavigationTemplate.Services
{
    public class ThemeConfig
    {
        [JsonPropertyName("mode")]
        public string? Mode { get; set; }
    }
}
